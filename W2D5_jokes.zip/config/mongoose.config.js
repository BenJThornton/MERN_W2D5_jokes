//1. import mongoose
const mongoose = require("mongoose");
const DB_NAME = "jokes_db";

mongoose.connect("mongodb://localhost/" + DB_NAME,{
    useNewUlrParser: true,
    useUnifiedTopology: true
})
    .then(()=>console.log(`Established a connection to ${DB_NAME}`))
    .catch(errObj => console.log("Something's wrong here..."))
