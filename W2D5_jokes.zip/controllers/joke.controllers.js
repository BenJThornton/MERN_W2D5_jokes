//CRUD

//Controller is importing the Model
const { JokeInfo } = require('os');
const Joke = require('../models/joke.model')

module.exports = {
    //----------READ & RETRIEVE------------//
    findAllJokes : (req, res) =>{
        // Below same as db.jokes.find
        Joke.find()
        // IMPORTANT what we return here is what we receive in REACT!
        .then(allJokes => res.json({jokes: allJokes}))
        .catch(err => res.json({message: "Something went wrong with the query", error: err}));
    },
    findOneJoke : (req, res) =>{
        Joke.findOne({_id: req.params.id})
        .then(oneJoke=>res.json({joke: oneJoke}))
        .catch(err => res.json({message: "Something went wrong with query", error: err}));
    },
    findJokeById : (req, res) =>{
        Joke.findById(req.params.id)
        .then(oneJoke=>res.json({joke: oneJoke}))
        .catch(err => res.json({message: "Something went wrong with query", error: err}));
    },

    //----------CREATE------------//
    createNewJoke : (req, res) =>{
        Joke.create(req.body)
        .then(newlyCreatedJoke => res.json({ joke: newlyCreatedJoke }))
        .catch(err => res.json({ message: 'Something went wrong', error: err }));
    },

    //----------UPDATE-----------//
    updateExistingJoke : (req, res) =>{
        Joke.findOneAndUpdate(
            {_id: req.params.id },
            req.body,
            {new: true, runValidators: true}
        )
        .then(updatedJoke =>res.json({joke: updatedJoke}))
        .catch(err => res.json({ message: 'Something went wrong', error: err }));
    },

    //---------DELETE-------------//
    deleteExistingJoke : (req, res) =>{
        Joke.deleteOne({_id: req.params.id})
        .then(result => res.json({ result: result }))
        .catch(err => res.json({ message: 'Something went wrong', error: err }));
    }
}